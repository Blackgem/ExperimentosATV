package info.androidtv.experimentos;

public class Comprobacion {
//    Clase seguridad
//    Lucky
//    permisos?
//    Licencia
//    actualización obligatoria
//    sistema anticopia de emergencia (bloqueo o killswitch)
//    sistema antimod (verificación firma o algo así)
}
